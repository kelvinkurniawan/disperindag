<?php

namespace app\Model;

use app\Core\BaseModel;

class TestModel extends BaseModel
{
    protected $table = 'test_table';
    protected $guarded = [];
}

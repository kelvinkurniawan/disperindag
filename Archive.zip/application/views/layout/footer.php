		<footer style="background-color: #075f1f">
			<div class="container py-5">
				<div class="row">
					<div class="col-md-6">
						<h6 class="text-white">
							Departement of Industry and Trade Special Province of Yogyakarta
						</h6>
						<span class="text-white">
							Jl. Kusumanegara No.9, Semaki, Kec. Umbulharjo, Kota Yogyakarta,
							Daerah Istimewa Yogyakarta 55166, Indonesia
						</span>
						<span class="text-white">
							Email: Mail@mail.com<br />
							Phone: +62 878-8888-8888
						</span>
					</div>
					<div class="col-md-6 text-end">
						<img
							src="<?=base_url('/assets/images/Logo Disperindag.png')?>"
							width="72"
						/>
					</div>
					<div class="col-md-12">
						<hr class="bg-white" />
						<span class="text-white text-center w-100">
							Copyright © 2022 All rights reserved.
						</span>
					</div>
				</div>
			</div>
		</footer>